<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title><?= $title ?? 'GRL-UNLOCK' ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f4f7fb;
}

.sidebar{
    width:260px;
    min-height:100vh;
    background:#0d6efd;
    color:#fff;
    position:fixed;
    left:0;
    top:0;
}

.sidebar h3{
    padding:25px;
    text-align:center;
    font-weight:bold;
}

.sidebar a{
    display:block;
    color:#fff;
    text-decoration:none;
    padding:14px 25px;
}

.sidebar a:hover{
    background:rgba(255,255,255,.15);
}

.content{
    margin-left:260px;
    padding:30px;
}

.card{
    border:none;
    border-radius:15px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
}

</style>

</head>

<body>

<div class="sidebar">

<h3>💙 GRL-UNLOCK</h3>

<a href="/dashboard">🏠 Dashboard</a>

<a href="/services">📦 Servicios</a>

<a href="#">👥 Clientes</a>

<a href="#">📋 Órdenes</a>

<a href="#">📦 Inventario</a>

<a href="#">📊 Reportes</a>

<a href="/logout">🚪 Cerrar sesión</a>

</div>

<div class="content">

<?= $content ?>

</div>

</body>
</html>