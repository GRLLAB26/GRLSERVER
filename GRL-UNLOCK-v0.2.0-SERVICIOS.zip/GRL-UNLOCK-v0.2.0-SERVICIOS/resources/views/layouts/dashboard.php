<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?= $title ?? 'GRL-UNLOCK' ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

<style>

body{
    margin:0;
    background:#f4f6f9;
    font-family:Arial,Helvetica,sans-serif;
}

.sidebar{

    width:250px;

    height:100vh;

    position:fixed;

    background:#0f172a;

    color:white;

    left:0;

    top:0;

}

.sidebar h3{

    padding:20px;

    text-align:center;

    border-bottom:1px solid #1e293b;

}

.sidebar a{

    display:block;

    color:white;

    text-decoration:none;

    padding:15px 20px;

}

.sidebar a:hover{

    background:#2563eb;

}

.main{

    margin-left:250px;

}

.navbar{

    background:white;

    border-bottom:1px solid #ddd;

}

.content{

    padding:30px;

}

.card{

    border:none;

    border-radius:12px;

    box-shadow:0 4px 10px rgba(0,0,0,.08);

}

</style>

</head>

<body>

<div class="sidebar">

<h3>🚀 GRL-UNLOCK</h3>

<a href="/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a>

<a href="/services"><i class="bi bi-grid"></i> Servicios</a>

<a href="#"><i class="bi bi-card-list"></i> Órdenes</a>

<a href="#"><i class="bi bi-people"></i> Clientes</a>

<a href="#"><i class="bi bi-wallet2"></i> Wallet</a>

<a href="#"><i class="bi bi-plug"></i> APIs</a>

<a href="/logout"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a>

</div>

<div class="main">

<nav class="navbar navbar-expand-lg px-4">

<span class="navbar-brand">

Panel Administrativo

</span>

</nav>

<div class="content">

<?= $content ?>

</div>

</div>

</body>

</html>