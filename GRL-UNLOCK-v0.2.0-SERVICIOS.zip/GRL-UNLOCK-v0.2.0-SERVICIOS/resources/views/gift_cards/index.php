<h1>🎁 Gift Cards</h1>
<a href="/gift-cards/create">
    ➕ Nueva Gift Card
</a>

<br><br>

<table border="1" cellpadding="8">

<tr>
    <th>ID</th>
    <th>Marca</th>
    <th>Nombre</th>
    <th>Valor</th>
    <th>Moneda</th>
    <th>Tipo</th>
    <th>Estado</th>
    <th>Código</th>
    <th>PIN</th>
    <th>Cliente</th>
    <th>Venta</th>
</tr>

<?php foreach ($gift_cards as $card): ?>

<tr>
    <td><?= $card['id'] ?></td>
    <td><?= $card['brand_name'] ?></td>
    <td><?= $card['reward_name'] ?></td>
    <td><?= $card['face_value'] ?></td>
    <td><?= $card['currency'] ?></td>
    <td><?= $card['fulfillment_type'] ?></td>
    <td><?= $card['status'] ?></td>
    <td><?= $card['code'] ?? '' ?></td>
    <td><?= $card['pin'] ?? '' ?></td>
    <td><?= $card['sold_to'] ?? '' ?></td>
    <td><?= $card['sold_at'] ?? '' ?></td>
</tr>

<?php endforeach; ?>

</table>