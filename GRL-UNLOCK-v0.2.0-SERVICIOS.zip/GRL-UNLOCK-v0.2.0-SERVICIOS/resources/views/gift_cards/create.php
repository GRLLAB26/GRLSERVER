<h1>➕ Nueva Gift Card</h1>

<form method="POST" action="/gift-cards">

    <label>Provider ID</label><br>
    <input type="number" name="provider_id" value="1"><br><br>

    <label>Marca</label><br>
    <input type="text" name="brand_name" placeholder="Amazon / Xbox"><br><br>

    <label>Brand Key</label><br>
    <input type="text" name="brand_key" placeholder="amazon"><br><br>

    <label>UTID</label><br>
    <input type="text" name="utid" placeholder="AMAZON-25-USD"><br><br>

    <label>Nombre</label><br>
    <input type="text" name="reward_name" placeholder="Amazon Gift Card $25"><br><br>

    <label>Moneda</label><br>
    <input type="text" name="currency" value="USD"><br><br>

    <label>Valor</label><br>
    <input type="number" step="0.01" name="face_value"><br><br>

    <label>Tipo</label><br>
    <input type="text" name="fulfillment_type"
    <input type="text" name="fulfillment_type" value="DIGITAL"><br><br>

<label>Código</label><br>
<input type="text" name="code" placeholder="XXXX-XXXX-XXXX"><br><br>

<label>PIN</label><br>
<input type="text" name="pin" placeholder="1234"><br><br>

<label>Estado</label><br>
<input type="text" name="status" value="active"><br><br>

<button type="submit">
    💾 Guardar Gift Card
</button>

</form>