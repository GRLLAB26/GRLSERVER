<h1>➕ Nueva Orden</h1>

<div class="card">

<div class="card-body">

<form action="/orders" method="POST">

<div class="mb-3">

<label class="form-label">
Cliente
</label>

<select name="client_id" class="form-control" required>

<option value="">
Seleccione cliente
</option>

<?php foreach($clients as $client): ?>

<option value="<?= $client['id'] ?>">
<?= htmlspecialchars($client['name']) ?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="mb-3">

<label class="form-label">
Servicio
</label>

<select name="service_id" class="form-control" required>

<option value="">
Seleccione servicio
</option>

<?php foreach($services as $service): ?>

<option value="<?= $service['id'] ?>">
<?= htmlspecialchars($service['name']) ?>
</option>

<?php endforeach; ?>

</select>

</div>


<div class="mb-3">

    <label class="form-label">
        Equipo
    </label>

    <input
        type="text"
        name="device"
        class="form-control"
        placeholder="iPhone">

</div>

<div class="row">

    <div class="col-md-6 mb-3">
        <label class="form-label">Marca</label>
        <input
            type="text"
            name="brand"
            class="form-control"
            placeholder="Apple">
    </div>

    <div class="col-md-6 mb-3">
        <label class="form-label">Modelo</label>
        <input
            type="text"
            name="model"
            class="form-control"
            placeholder="iPhone 16 Pro">
    </div>

</div>

<div class="row">

    <div class="col-md-6 mb-3">
        <label class="form-label">IMEI</label>
        <input
            type="text"
            name="imei"
            class="form-control">
    </div>

    <div class="col-md-6 mb-3">
        <label class="form-label">Número de serie</label>
        <input
            type="text"
            name="serial_number"
            class="form-control">
    </div>

</div>

<div class="row">

    <div class="col-md-6 mb-3">
        <label class="form-label">Color</label>
        <input
            type="text"
            name="color"
            class="form-control">
    </div>

    <div class="col-md-6 mb-3">
        <label class="form-label">Contraseña</label>
        <input
            type="text"
            name="password"
            class="form-control">
    </div>

</div>
Problema
<div class="mb-3">

    <label class="form-label">
        Observaciones
    </label>

    <textarea
        name="notes"
        class="form-control"
        rows="3"></textarea>

</div>
Precio
<div class="row">

    <div class="col-md-6 mb-3">

        <label class="form-label">
            Anticipo
        </label>

        <input
            type="number"
            step="0.01"
            name="advance"
            class="form-control"
            value="0">

    </div>

    <div class="col-md-6 mb-3">

        <label class="form-label">
            Fecha estimada de entrega
        </label>

        <input
            type="date"
            name="delivery_date"
            class="form-control">

    </div>

</div>
<button type="submit" class="btn btn-primary">
    💾 Guardar Orden
</button>

<a href="/orders" class="btn btn-secondary">
    Cancelar
</a>

</form>

</div>

</div>

