<h1>📋 Orden #<?= $order['id'] ?></h1>

<div class="card">

<div class="card-body">

<p>
<strong>Cliente:</strong>
<?= htmlspecialchars($order['client_name']) ?>
</p>

<p>
<strong>Servicio:</strong>
<?= htmlspecialchars($order['service_name']) ?>
</p>

<p>
<strong>Equipo:</strong>
<?= htmlspecialchars($order['device']) ?>
</p>

<p>
<strong>Marca:</strong>
<?= htmlspecialchars($order['brand'] ?? '') ?>
</p>

<p>
<strong>Modelo:</strong>
<?= htmlspecialchars($order['model'] ?? '') ?>
</p>

<p>
<strong>IMEI:</strong>
<?= htmlspecialchars($order['imei'] ?? '') ?>
</p>


<p>
<strong>Estado:</strong>

<span class="badge 
<?php
echo match($order['status']) {
    'Pendiente' => 'bg-warning',
    'En proceso' => 'bg-primary',
    'Terminado' => 'bg-success',
    'Entregado' => 'bg-success',
    'Cancelado' => 'bg-danger',
    default => 'bg-secondary'
};
?>">
<?= htmlspecialchars($order['status']) ?>
</span>

</p>
<form action="/orders/status/<?= $order['id'] ?>" method="POST">

<label class="form-label">
Cambiar estado
</label>

<select name="status" class="form-control mb-3">

<option value="Pendiente" <?= $order['status']=='Pendiente'?'selected':'' ?>>
🟡 Pendiente
</option>

<option value="En proceso" <?= $order['status']=='En proceso'?'selected':'' ?>>
🔵 En proceso
</option>

<option value="Terminado" <?= $order['status']=='Terminado'?'selected':'' ?>>
🟢 Terminado
</option>

<option value="Entregado" <?= $order['status']=='Entregado'?'selected':'' ?>>
✅ Entregado
</option>

<option value="Cancelado" <?= $order['status']=='Cancelado'?'selected':'' ?>>
🔴 Cancelado
</option>

</select>

<button type="submit" class="btn btn-success">
Actualizar Estado
</button>

</form>

<p>
<strong>Precio:</strong>

$<?= number_format($order['price'],2) ?>

</p>


<p>
<strong>Anticipo:</strong>

$<?= number_format($order['advance'] ?? 0,2) ?>

</p>


<p>
<strong>Pendiente:</strong>

<span class="text-danger">

$<?= number_format(
($order['price'] ?? 0) - ($order['advance'] ?? 0),
2
) ?>

</span>

</p>


<a href="/orders" class="btn btn-secondary">
⬅ Volver
</a>

<a href="/orders" class="btn btn-primary">
✏️ Editar próximamente
</a>


</div>

</div>