<h1>📋 Órdenes</h1>

<a href="/orders/create" class="btn btn-primary mb-3">
    ➕ Nueva Orden
</a>

<div class="card">

<div class="card-body">

<table class="table table-striped">

<thead>
<tr>
    <th>ID</th>
    <th>Cliente</th>
    <th>Servicio</th>
    <th>Equipo</th>
    <th>IMEI</th>
    <th>Precio</th>
    <th>Anticipo</th>
    <th>Pendiente</th>
    <th>Estado</th>
    <th>Acción</th>
</tr>
</thead>

<tbody>

<?php if(empty($orders)): ?>

<tr>
    <td colspan="10" class="text-center">
        No hay órdenes registradas
    </td>
</tr>

<?php else: ?>

<?php foreach($orders as $order): ?>

<tr>

<td>
<?= $order['id'] ?>
</td>

<td>
<?= htmlspecialchars($order['client_name'] ?? '') ?>
</td>

<td>
<?= htmlspecialchars($order['service_name'] ?? '') ?>
</td>

<td>
<?= htmlspecialchars($order['device'] ?? '') ?>
</td>

<td>
<?= htmlspecialchars($order['imei'] ?? '') ?>
</td>

<td>
$<?= number_format($order['price'],2) ?>
</td>

<td>
$<?= number_format($order['advance'],2) ?>
</td>

<td>
$<?= number_format(($order['price'] ?? 0) - ($order['advance'] ?? 0), 2) ?>
</td>

<td>

<span class="badge bg-warning">
<?= htmlspecialchars($order['status'] ?? '') ?>
</span>

</td>

<td>

<a href="/orders/view/<?= $order['id'] ?>" 
class="btn btn-sm btn-info">
👁️ Ver
</a>

</td>

</tr>

<?php endforeach; ?>

<?php endif; ?>

</tbody>

</table>

</div>

</div>