<h1><?= $title ?></h1>

<form action="/orders" method="POST">

    <p>
        <label>Cliente</label><br>
        <select name="client_id" required>
            <?php foreach ($clients as $client): ?>
                <option value="<?= $client['id'] ?>">
                    <?= htmlspecialchars($client['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>

    <p>
        <label>Servicio</label><br>
        <select name="service_id" required>
            <?php foreach ($services as $service): ?>
                <option value="<?= $service['id'] ?>">
                    <?= htmlspecialchars($service['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>

    <p>
        <label>Dispositivo</label><br>
        <input type="text" name="device" required>
    </p>

    <p>
        <label>Marca</label><br>
        <input type="text" name="brand" required>
    </p>

    <p>
        <label>Modelo</label><br>
        <input type="text" name="model" required>
    </p>

    <p>
        <label>IMEI</label><br>
        <input type="text" name="imei" maxlength="15" required>
    </p>

    <p>
        <label>Número de serie</label><br>
        <input type="text" name="serial_number">
    </p>

    <p>
        <label>Color</label><br>
        <input type="text" name="color">
    </p>

    <p>
        <label>Contraseña</label><br>
        <input type="text" name="password">
    </p>

    <p>
        <label>Problema</label><br>
        <textarea name="problem"></textarea>
    </p>

    <p>
        <label>Notas</label><br>
        <textarea name="notes"></textarea>
    </p>

    <p>
        <label>Precio</label><br>
        <input type="number" step="0.01" name="price">
    </p>

    <p>
        <label>Anticipo</label><br>
        <input type="number" step="0.01" name="advance">
    </p>

    <p>
        <label>Fecha de entrega</label><br>
        <input type="date" name="delivery_date">
    </p>

    <button type="submit">💾 Crear Orden IMEI</button>

</form>