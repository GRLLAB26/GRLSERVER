<div class="container-fluid">

<h2 class="mb-4">

Dashboard

</h2>

<div class="row g-4">

<div class="col-md-3">

<div class="card">

<div class="card-body">

<h6>Servicios</h6>

<h2><?= $services ?></h2>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card">

<div class="card-body">

<h6>Órdenes</h6>

<h2>$0</h2>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card">

<div class="card-body">

<h6>Clientes</h6>

<h2><?= $clients ?></h2>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card">

<div class="card-body">

<h6>Balance</h6>

<h2>$<?= number_format($balance, 2) ?></h2>

</div>

</div>

</div>

</div>

</div>