<h1>✏️ Editar Provider</h1>

<p>
    <a href="/providers">⬅️ Volver a Providers</a>
</p>

<form action="/providers/update/<?= $provider['id'] ?>" method="POST">

<p>
Nombre<br>
<input 
    type="text" 
    name="name" 
    value="<?= htmlspecialchars($provider['name']) ?>"
    required
>
</p>

<p>
Website<br>
<input 
    type="text" 
    name="website"
    value="<?= htmlspecialchars($provider['website']) ?>"
>
</p>

<p>
API URL<br>
<input 
    type="text" 
    name="api_url"
    value="<?= htmlspecialchars($provider['api_url']) ?>"
>
</p>

<p>
Usuario<br>
<input 
    type="text" 
    name="username"
    value="<?= htmlspecialchars($provider['username']) ?>"
>
</p>

<p>
API Key<br>
<textarea name="api_key"><?= htmlspecialchars($provider['api_key']) ?></textarea>
</p>

<p>
Moneda<br>

<select name="currency">

<option value="USD" <?= $provider['currency'] == 'USD' ? 'selected' : '' ?>>
USD
</option>

<option value="MXN" <?= $provider['currency'] == 'MXN' ? 'selected' : '' ?>>
MXN
</option>

</select>

</p>

<p>
Saldo<br>
<input 
    type="number" 
    step="0.01"
    name="balance"
    value="<?= $provider['balance'] ?>"
>
</p>

<button type="submit">
💾 Actualizar Provider
</button>

</form>