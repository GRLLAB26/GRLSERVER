<h1>Nuevo Provider</h1>

<form action="/providers" method="POST">

<p>
Nombre<br>
<input type="text" name="name" required>
</p>

<p>
Website<br>
<input type="text" name="website">
</p>

<p>
API URL<br>
<input type="text" name="api_url">
</p>

<p>
Usuario<br>
<input type="text" name="username">
</p>

<p>
API Key<br>
<textarea name="api_key"></textarea>
</p>

<p>
Moneda<br>

<select name="currency">
    <option value="USD">USD</option>
    <option value="MXN">MXN</option>
</select>

</p>

<p>
Saldo<br>
<input type="number" step="0.01" name="balance" value="0">
</p>

<button type="submit">
💾 Guardar Provider
</button>

</form>