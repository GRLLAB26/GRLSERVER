<h1>Providers</h1>

<p>
    <a href="/providers/create">➕ Nuevo Provider</a>
</p>

<table border="1" cellpadding="8">

<tr>
    <th>Nombre</th>
    <th>Moneda</th>
    <th>Saldo</th>
    <th>Estado</th>
</tr>

<?php foreach ($providers as $provider): ?>

<tr>
    <td><?= htmlspecialchars($provider['name']) ?></td>
    <td><?= htmlspecialchars($provider['currency']) ?></td>
    <td>$<?= number_format($provider['balance'],2) ?></td>
    <td><?= $provider['status'] ? '🟢 Activo' : '🔴 Inactivo' ?></td>
</tr>

<?php endforeach; ?>

</table>