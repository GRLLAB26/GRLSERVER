<h1>✏️ Editar Servicio</h1>

<form action="/services/update?id=<?= $service['id'] ?>" method="POST">

    <p>
        <label>Nombre del servicio</label><br>
        <input
            type="text"
            name="name"
            value="<?= htmlspecialchars($service['name']) ?>"
            required>
    </p>

    <p>
        <label>Proveedor</label><br>
        <input
            type="text"
            name="provider"
            value="<?= htmlspecialchars($service['provider']) ?>"
            required>
    </p>

    <p>
        <label>Categoría</label><br>
        <input
            type="text"
            name="category"
            value="<?= htmlspecialchars($service['category']) ?>">
    </p>

    <p>
        <label>Costo</label><br>
        <input
            type="number"
            step="0.01"
            name="cost"
            value="<?= $service['cost'] ?>"
            required>
    </p>

    <p>
        <label>Precio</label><br>
        <input
            type="number"
            step="0.01"
            name="price"
            value="<?= $service['price'] ?>"
            required>
    </p>

    <p>
        <label>Tiempo estimado</label><br>
        <input
            type="text"
            name="estimated_time"
            value="<?= htmlspecialchars($service['estimated_time']) ?>">
    </p>

    <br>

    <button type="submit">
        💾 Actualizar Servicio
    </button>

    <a href="/services">
        Cancelar
    </a>

</form>