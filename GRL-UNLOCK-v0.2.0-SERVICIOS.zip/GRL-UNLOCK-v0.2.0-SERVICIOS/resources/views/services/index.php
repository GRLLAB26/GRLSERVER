<h1>📦 Servicios</h1>

<p>
   <a href="/services/create" class="btn btn-primary mb-3">
    <i class="bi bi-plus-circle"></i> Nuevo Servicio
</a>
</p>

<table border="1" cellpadding="10" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>ID</th>
            <th>Servicio</th>
            <th>Acciones</th>De
            <th>Proveedor</th>
            <th>Categoría</th>
            <th>Costo</th>
            <th>Precio</th>
            <th>Estado</th>
        </tr>
    </thead>

    <tbody>

    <?php if (empty($services)): ?>

        <tr>
            <td colspan="7" style="text-align:center;">
                No hay servicios registrados.
            </td>
        </tr>

    <?php else: ?>

        <?php foreach ($services as $service): ?>

        <tr>

            <td><?= $service['id'] ?></td>

            <td><?= htmlspecialchars($service['name']) ?></td>

            <td><?= htmlspecialchars($service['provider']) ?></td>

            <td><?= htmlspecialchars($service['category']) ?></td>

            <td>$<?= number_format($service['cost'], 2) ?></td>

            <td>$<?= number_format($service['price'], 2) ?></td>

            <td>$<?= number_format($service['price'] - $service['cost'], 2) ?>
            </td>

            <td>
                <?= $service['status'] ? '🟢 Activo' : '🔴 Inactivo' ?>
                <td>
    <a href="/services/edit?id=<?= $service['id'] ?>">
    ✏️ Editar
</a>

<form action="/services/delete" method="POST" style="display:inline;">
    <input 
        type="hidden" 
        name="id" 
        value="<?= $service['id'] ?>">

    <button type="submit">
        🔴 Desactivar
    </button>
</form>
    </a>
</td>
            </td>

        </tr>

        <?php endforeach; ?>

    <?php endif; ?>

    </tbody>

</table>