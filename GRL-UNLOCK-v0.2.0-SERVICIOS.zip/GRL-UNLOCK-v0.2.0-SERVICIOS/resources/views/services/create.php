<h1>➕ Nuevo Servicio</h1>

<form action="/services" method="POST">

    <p>
        <label>Nombre del servicio</label><br>
        <input type="text" name="name" required>
    </p>

    <p>
        <label>Proveedor</label><br>
        <input type="text" name="provider" required>
    </p>

    <p>
        <label>Categoría</label><br>
        <input type="text" name="category">
    </p>

    <p>
        <label>Costo</label><br>
        <input type="number" step="0.01" name="cost" required>
    </p>

    <p>
        <label>Precio</label><br>
        <input type="number" step="0.01" name="price" required>
    </p>

    <p>
        <label>Tiempo estimado</label><br>
        <input type="text" name="estimated_time">
    </p>

    <br>

    <button type="submit">
        💾 Guardar Servicio
    </button>

    <a href="/services">
        Cancelar
    </a>

</form>