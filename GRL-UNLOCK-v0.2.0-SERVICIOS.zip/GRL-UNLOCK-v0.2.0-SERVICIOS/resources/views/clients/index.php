<h1>👥 Clientes</h1>

<a href="/clients/create" class="btn btn-primary mb-3">
    ➕ Nuevo Cliente
</a>

<div class="card">

<div class="card-body">

<table class="table table-striped">

<thead>
<tr>
    <th>ID</th>
    <th>Nombre</th>
    <th>Teléfono</th>
    <th>Email</th>
    <th>Estado</th>
</tr>
</thead>

<tbody>

<?php if(empty($clients)): ?>

<tr>
    <td colspan="5" class="text-center">
        No hay clientes registrados
    </td>
</tr>

<?php else: ?>

<?php foreach($clients as $client): ?>

<tr>

<td>
<?= $client['id'] ?>
</td>

<td>
<?= htmlspecialchars($client['name']) ?>
</td>

<td>
<?= htmlspecialchars($client['phone']) ?>
</td>

<td>
<?= htmlspecialchars($client['email']) ?>
</td>

<td>

<?php if($client['status'] == 1): ?>

<span class="badge bg-success">
Activo
</span>

<?php else: ?>

<span class="badge bg-secondary">
Inactivo
</span>

<?php endif; ?>

</td>

</tr>

<?php endforeach; ?>

<?php endif; ?>

</tbody>

</table>

</div>

</div>