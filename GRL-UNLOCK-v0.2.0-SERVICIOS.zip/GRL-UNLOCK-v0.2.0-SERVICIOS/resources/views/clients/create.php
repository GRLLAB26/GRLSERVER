<h1>➕ Nuevo Cliente</h1>

<div class="card">

<div class="card-body">

<form action="/clients" method="POST">

<div class="mb-3">

<label class="form-label">
Nombre completo
</label>

<input 
type="text"
name="name"
class="form-control"
required>

</div>


<div class="mb-3">

<label class="form-label">
Teléfono
</label>

<input 
type="text"
name="phone"
class="form-control">

</div>


<div class="mb-3">

<label class="form-label">
Correo electrónico
</label>

<input 
type="email"
name="email"
class="form-control">

</div>


<div class="mb-3">

<label class="form-label">
Dirección
</label>

<textarea
name="address"
class="form-control"></textarea>

</div>


<div class="mb-3">

<label class="form-label">
Notas
</label>

<textarea
name="notes"
class="form-control"></textarea>

</div>


<button type="submit" class="btn btn-primary">
💾 Guardar Cliente
</button>


<a href="/clients" class="btn btn-secondary">
Cancelar
</a>


</form>

</div>

</div>