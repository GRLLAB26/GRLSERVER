<div class="card">

    <h1>🚀 GRL-UNLOCK</h1>

    <?php if (!empty($error)): ?>

        <div class="error">

            <?= $error ?>

        </div>

    <?php endif; ?>

    <form method="POST" action="/login">

        <input
            type="email"
            name="email"
            placeholder="Correo electrónico"
            required
        >

        <input
            type="password"
            name="password"
            placeholder="Contraseña"
            required
        >

        <button type="submit">

            Iniciar sesión

        </button>

    </form>

</div>