<h1>💳 Ventas de Gift Cards</h1>

<a href="/gift-card-sales/create">
    ➕ Nueva Venta
</a>

<br><br>

<table border="1" cellpadding="8">

<tr>
    <th>ID</th>
    <th>Gift Card</th>
    <th>Marca</th>
    <th>Cliente</th>
    <th>Precio</th>
    <th>Pago</th>
    <th>Entrega</th>
    <th>Fecha</th>
</tr>

<?php foreach ($sales as $sale): ?>

<tr>
    <td><?= $sale['id'] ?></td>
    <td><?= $sale['reward_name'] ?></td>
    <td><?= $sale['brand_name'] ?></td>
    <td><?= $sale['client_name'] ?? 'Sin cliente' ?></td>
    <td>$<?= number_format($sale['sale_price'], 2) ?></td>
    <td><?= $sale['payment_status'] ?></td>
    <td><?= $sale['delivery_status'] ?></td>
    <td><?= $sale['created_at'] ?></td>
</tr>

<?php endforeach; ?>

</table>