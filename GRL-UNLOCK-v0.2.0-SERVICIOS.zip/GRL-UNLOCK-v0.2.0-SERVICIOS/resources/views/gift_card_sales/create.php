<h1>💳 Nueva Venta de Gift Card</h1>

<form method="POST" action="/gift-card-sales">

    <label>Gift Card ID</label><br>
    <input type="number" name="gift_card_id" required>
    <br><br>

    <select name="client_id" required>
    <option value="">Selecciona un cliente</option>

    <?php foreach ($clients as $client): ?>
        <option value="<?= $client['id'] ?>">
            <?= htmlspecialchars($client['name']) ?>
        </option>
    <?php endforeach; ?>

</select>

    <br><br>

    <label>Precio de Venta</label><br>
    <input type="number" step="0.01" name="sale_price" required>
    <br><br>

    <label>Estado del Pago</label><br>
    <select name="payment_status">
        <option value="pending">Pendiente</option>
        <option value="paid">Pagado</option>
        <option value="refunded">Reembolsado</option>
    </select>

    <br><br>

    <label>Estado de Entrega</label><br>
    <select name="delivery_status">
        <option value="pending">Pendiente</option>
        <option value="delivered">Entregada</option>
    </select>

    <br><br>

    <button type="submit">
        💾 Guardar Venta
    </button>
public static function create(array $data): bool
{
    $db = Database::connection();

    $stmt = $db->prepare("
        INSERT INTO gift_card_sales (
            gift_card_id,
            client_id,
            sale_price,
            payment_status,
            delivery_status
        ) VALUES (
            :gift_card_id,
            :client_id,
            :sale_price,
            :payment_status,
            :delivery_status
        )
    ");

    return $stmt->execute([
        ':gift_card_id'     => $data['gift_card_id'],
        ':client_id'        => $data['client_id'],
        ':sale_price'       => $data['sale_price'],
        ':payment_status'   => $data['payment_status'],
        ':delivery_status'  => $data['delivery_status'],
    ]);
}
</form>