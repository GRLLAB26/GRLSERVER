<?php

require_once __DIR__ . '/../bootstrap/app.php';

use App\Core\Database;

$db = Database::connection();

$stmt = $db->query("
    SELECT id, name, email, role
    FROM users
");

echo "<pre>";
print_r($stmt->fetchAll());
echo "</pre>";