<?php

require_once __DIR__ . '/../bootstrap/app.php';

use App\Core\Database;

try {
    $db = Database::connection();

    echo "✅ Conexión exitosa<br>";

    $stmt = $db->query("SELECT DATABASE() AS db");
    $row = $stmt->fetch();

    echo "Base de datos: " . $row['db'];

} catch (Throwable $e) {
    echo $e->getMessage();
}