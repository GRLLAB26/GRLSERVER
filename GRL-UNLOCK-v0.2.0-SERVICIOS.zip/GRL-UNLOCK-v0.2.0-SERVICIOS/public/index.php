<?php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap/app.php';

$router = require __DIR__ . '/../routes/web.php';

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

$router->dispatch(
    $uri,
    $_SERVER['REQUEST_METHOD']
);