<?php

require_once __DIR__ . '/../bootstrap/app.php';

use App\Core\Database;

try {
    $db = Database::connection();

    echo "<h2>Conexión OK</h2>";

    $stmt = $db->query("DESCRIBE services");

    echo "<pre>";
    print_r($stmt->fetchAll());
    echo "</pre>";

} catch (Throwable $e) {
    echo "<h2>Error</h2>";
    echo "<pre>" . $e->getMessage() . "</pre>";
}