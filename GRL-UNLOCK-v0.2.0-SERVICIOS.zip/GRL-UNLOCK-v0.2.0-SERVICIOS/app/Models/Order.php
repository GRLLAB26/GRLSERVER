<?php

namespace App\Models;

use App\Core\Database;
use PDO;

class Order
{
    public static function create(array $data): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            INSERT INTO orders
            (
                client_id,
                service_id,
                device,
                brand,
                model,
                imei,
                serial_number,
                color,
                password,
                problem,
                notes,
                status,
                price,
                advance,
                delivery_date
            )
            VALUES
            (
                :client_id,
                :service_id,
                :device,
                :brand,
                :model,
                :imei,
                :serial_number,
                :color,
                :password,
                :problem,
                :notes,
                :status,
                :price,
                :advance,
                :delivery_date
            )
        ");

        return $stmt->execute([
            ':client_id'     => $data['client_id'],
            ':service_id'    => $data['service_id'],
            ':device'        => $data['device'],
            ':brand'         => $data['brand'],
            ':model'         => $data['model'],
            ':imei'          => $data['imei'],
            ':serial_number' => $data['serial_number'],
            ':color'         => $data['color'],
            ':password'      => $data['password'],
            ':problem'       => $data['problem'],
            ':notes'         => $data['notes'],
            ':status'        => $data['status'] ?? 'Pendiente',
            ':price'         => $data['price'],
            ':advance'       => $data['advance'],
            ':delivery_date' => $data['delivery_date']
        ]);
    }
        public static function count(): int
    {
        $db = Database::connection();

        $stmt = $db->query("SELECT COUNT(*) FROM orders");

        return (int) $stmt->fetchColumn();
    }
    public static function all(): array
{
    $db = Database::connection();

    $stmt = $db->query("
        SELECT
            orders.*,
            clients.name AS client_name,
            services.name AS service_name
        FROM orders
        LEFT JOIN clients ON clients.id = orders.client_id
        LEFT JOIN services ON services.id = orders.service_id
        ORDER BY orders.id DESC
    ");

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
public static function find(int $id): ?array
{
    $db = Database::connection();

    $stmt = $db->prepare("
        SELECT
            orders.*,
            clients.name AS client_name,
            services.name AS service_name
        FROM orders
        LEFT JOIN clients ON clients.id = orders.client_id
        LEFT JOIN services ON services.id = orders.service_id
        WHERE orders.id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id
    ]);

    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    return $order ?: null;
}
public static function updateStatus(int $id, string $status): bool
{
    $db = Database::connection();

    $stmt = $db->prepare("
        UPDATE orders
        SET status = :status
        WHERE id = :id
    ");

    return $stmt->execute([
        ':status' => $status,
        ':id' => $id
    ]);
}
}