<?php

namespace App\Models;

use App\Core\Database;
use PDO;

class GiftCardSale
{
    public static function all(): array
    {
        $db = Database::connection();

        $stmt = $db->query("
            SELECT
                gcs.*,
                gc.reward_name,
                gc.brand_name,
                c.name AS client_name
            FROM gift_card_sales gcs
            INNER JOIN gift_cards gc
                ON gc.id = gcs.gift_card_id
            LEFT JOIN clients c
                ON c.id = gcs.client_id
            ORDER BY gcs.id DESC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function create(array $data): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            INSERT INTO gift_card_sales
            (
                gift_card_id,
                client_id,
                sale_price,
                payment_status,
                delivery_status
            )
            VALUES
            (
                :gift_card_id,
                :client_id,
                :sale_price,
                :payment_status,
                :delivery_status
            )
        ");

        return $stmt->execute([
            'gift_card_id'    => $data['gift_card_id'],
            'client_id'       => $data['client_id'] ?: null,
            'sale_price'      => $data['sale_price'],
            'payment_status'  => $data['payment_status'] ?? 'pending',
            'delivery_status' => $data['delivery_status'] ?? 'pending',
        ]);
    }
}