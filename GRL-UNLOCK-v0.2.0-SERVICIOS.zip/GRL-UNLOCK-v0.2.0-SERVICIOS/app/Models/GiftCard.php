<?php

namespace App\Models;

use App\Core\Database;
use PDO;

class GiftCard
{
    public static function all(): array
    {
        $db = Database::connection();

        $stmt = $db->query("
            SELECT *
            FROM gift_cards
            ORDER BY created_at DESC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function create (array $data): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            INSERT INTO gift_cards (
                provider_id,
                brand_key,
                brand_name,
                utid,
                reward_name,
                currency,
                face_value,
                fulfillment_type,
                status
            ) VALUES (
                :provider_id,
                :brand_key,
                :brand_name,
                :utid,
                :reward_name,
                :currency,
                :face_value,
                :fulfillment_type,
                :status
            )
        ");

        return $stmt->execute([
            'provider_id' => $data['provider_id'],
            'brand_key' => $data['brand_key'],
            'brand_name' => $data['brand_name'],
            'utid' => $data['utid'],
            'reward_name' => $data['reward_name'],
            'currency' => $data['currency'],
            'face_value' => $data['face_value'],
            'fulfillment_type' => $data['fulfillment_type'],
            'status' => $data['status'] ?? 'active',
        ]);
    }
}