<?php

namespace App\Models;

use App\Core\Database;
use PDO;

class Service
{
    public static function all(): array
    {
        $db = Database::connection();

        $stmt = $db->query("
            SELECT *
            FROM services
            ORDER BY id DESC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find(int $id): ?array
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            SELECT *
            FROM services
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $id
        ]);

        $service = $stmt->fetch(PDO::FETCH_ASSOC);

        return $service ?: null;
    }
    public static function update(int $id, array $data): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            UPDATE services
            SET
                name = :name,
                provider = :provider,
                category = :category,
                cost = :cost,
                price = :price,
                estimated_time = :estimated_time,
                status = :status
            WHERE id = :id
        ");

        return $stmt->execute([
            ':id' => $id,
            ':name' => $data['name'],
            ':provider' => $data['provider'],
            ':category' => $data['category'],
            ':cost' => $data['cost'],
            ':price' => $data['price'],
            ':estimated_time' => $data['estimated_time'],
            ':status' => $data['status'] ?? 1
        ]);
    }
    public static function count(): int
{
    $db = Database::connection();

    $stmt = $db->query("
        SELECT COUNT(*) AS total
        FROM services
    ");

    return (int) $stmt->fetchColumn();
}
public static function totalBalance(): float
{
    $db = Database::connection();

    $stmt = $db->query("
        SELECT SUM(price - cost)
        FROM services
        WHERE status = 1
    ");

    return (float) ($stmt->fetchColumn() ?? 0);
}
public static function deactivate(int $id): bool
{
    $db = Database::connection();

    $stmt = $db->prepare("
        UPDATE services
        SET status = 0
        WHERE id = :id
    ");

    return $stmt->execute([
        ':id' => $id
    ]);
}
}