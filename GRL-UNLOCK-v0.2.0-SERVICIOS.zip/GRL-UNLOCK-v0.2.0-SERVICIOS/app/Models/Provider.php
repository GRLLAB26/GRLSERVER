<?php

namespace App\Models;

use App\Core\Database;
use PDO;

class Provider
{
    public static function all(): array
    {
        $db = Database::connection();

        $stmt = $db->query("
            SELECT *
            FROM providers
            ORDER BY name ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public static function create(array $data): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            INSERT INTO providers
            (
                name,
                website,
                api_url,
                username,
                api_key,
                currency,
                balance,
                status
            )
            VALUES
            (
                :name,
                :website,
                :api_url,
                :username,
                :api_key,
                :currency,
                :balance,
                :status
            )
        ");

        return $stmt->execute([
            ':name'     => $data['name'],
            ':website'  => $data['website'],
            ':api_url'  => $data['api_url'],
            ':username' => $data['username'],
            ':api_key'  => $data['api_key'],
            ':currency' => $data['currency'],
            ':balance'  => $data['balance'],
            ':status'   => $data['status'] ?? 1
        ]);
    }


    public static function find(int $id): array|false
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            SELECT *
            FROM providers
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $id
        ]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }


    public static function update(int $id, array $data): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            UPDATE providers
            SET
                name = :name,
                website = :website,
                api_url = :api_url,
                username = :username,
                api_key = :api_key,
                currency = :currency,
                balance = :balance
            WHERE id = :id
        ");

        return $stmt->execute([
            ':id'       => $id,
            ':name'     => $data['name'],
            ':website'  => $data['website'],
            ':api_url'  => $data['api_url'],
            ':username' => $data['username'],
            ':api_key'  => $data['api_key'],
            ':currency' => $data['currency'],
            ':balance'  => $data['balance']
        ]);
    }


    public static function delete(int $id): bool
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            DELETE FROM providers
            WHERE id = :id
        ");

        return $stmt->execute([
            ':id' => $id
        ]);
    }
}