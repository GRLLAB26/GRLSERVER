<?php

namespace App\Models;

use App\Core\Database;
use PDO;

class Client
{
    public static function all(): array
    {
        $db = Database::connection();

        $stmt = $db->query("
            SELECT id, name
            FROM clients
            ORDER BY name ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find(int $id): ?array
    {
        $db = Database::connection();

        $stmt = $db->prepare("
            SELECT *
            FROM clients
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            'id' => $id
        ]);

        $client = $stmt->fetch(PDO::FETCH_ASSOC);

        return $client ?: null;
    }
}