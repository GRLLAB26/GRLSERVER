<?php

namespace App\Core;

class Controller
{
    /**
     * Renderizar una vista
     */
    protected function view(string $view, array $data = []): void
    {
        Response::view($view, $data);
    }

    /**
     * Respuesta JSON
     */
    protected function json(array $data, int $status = 200): void
    {
        Response::json($data, $status);
    }

    /**
     * Redireccionar
     */
    protected function redirect(string $url): void
    {
        Response::redirect($url);
    }

    /**
     * Obtener una instancia de Request
     */
    protected function request(): Request
    {
        return new Request();
    }
}