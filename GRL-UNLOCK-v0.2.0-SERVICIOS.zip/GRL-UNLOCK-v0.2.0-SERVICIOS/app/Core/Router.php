<?php

namespace App\Core;

class Router
{
    protected array $routes = [];


    public function addRoute(string $method, string $uri, callable|array $action): void
    {
        $this->routes[] = [
            'method' => strtoupper($method),
            'uri' => $uri,
            'action' => $action,
        ];
    }


    public function get(string $uri, callable|array $action): void
    {
        $this->addRoute('GET', $uri, $action);
    }


    public function post(string $uri, callable|array $action): void
    {
        $this->addRoute('POST', $uri, $action);
    }


    public function put(string $uri, callable|array $action): void
    {
        $this->addRoute('PUT', $uri, $action);
    }


    public function delete(string $uri, callable|array $action): void
    {
        $this->addRoute('DELETE', $uri, $action);
    }


    public function dispatch(string $uri, string $method = 'GET'): mixed
    {
        foreach ($this->routes as $route) {

            if ($route['method'] !== strtoupper($method)) {
                continue;
            }

            $pattern = preg_replace(
                '/\{[^}]+\}/',
                '([^/]+)',
                $route['uri']
            );

            if (preg_match('#^' . $pattern . '$#', $uri, $matches)) {

                array_shift($matches);

                return $this->callAction(
                    $route['action'],
                    $matches
                );
            }
        }

        http_response_code(404);

        return null;
    }


    public function resolve(string $method, string $uri): mixed
    {
        return $this->dispatch($uri, $method);
    }


    protected function callAction(callable|array $action, array $params = []): mixed
    {
        if (is_callable($action)) {
            return $action(...$params);
        }

        if (is_array($action) && count($action) === 2) {

            [$controller, $method] = $action;

            if (is_string($controller)) {
                $controller = new $controller();
            }

            return $controller->$method(...$params);
        }

        throw new \InvalidArgumentException('Invalid route action.');
    }
}