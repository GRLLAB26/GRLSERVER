<?php

namespace App\Core;

class Response
{
    /**
     * Devolver una respuesta JSON
     */
    public static function json(array $data, int $status = 200): void
    {
        http_response_code($status);

        header('Content-Type: application/json; charset=utf-8');

        echo json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        exit;
    }

    /**
     * Redireccionar
     */
    public static function redirect(string $url): void
    {
        header("Location: {$url}");
        exit;
    }

    /**
     * Cargar una vista
     */
    public static function view(string $view, array $data = []): void
{
    extract($data);

    $viewFile = __DIR__ . '/../../resources/views/' . $view . '.php';

    if (!file_exists($viewFile)) {
        http_response_code(404);
        exit("Vista '{$view}' no encontrada.");
    }

    ob_start();

    require $viewFile;

    $content = ob_get_clean();

    $layout = __DIR__ . '/../../resources/views/layouts/dashboard.php';

    if (file_exists($layout)) {
        require $layout;
    } else {
        echo $content;
    }

    exit;
}

    /**
     * Texto plano
     */
    public static function text(string $message, int $status = 200): void
    {
        http_response_code($status);

        header('Content-Type: text/plain; charset=utf-8');

        echo $message;

        exit;
    }
}