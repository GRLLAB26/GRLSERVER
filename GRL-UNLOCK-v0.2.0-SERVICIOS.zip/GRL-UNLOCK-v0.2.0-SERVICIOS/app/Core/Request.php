<?php

namespace App\Core;

class Request
{
    /**
     * Obtener un valor por GET
     */
    public function get(string $key, mixed $default = null): mixed
    {
        return $_GET[$key] ?? $default;
    }

    /**
     * Obtener un valor por POST
     */
    public function post(string $key, mixed $default = null): mixed
    {
        return $_POST[$key] ?? $default;
    }

    /**
     * Obtener todos los datos GET
     */
    public function allGet(): array
    {
        return $_GET;
    }

    /**
     * Obtener todos los datos POST
     */
    public function allPost(): array
    {
        return $_POST;
    }

    /**
     * Método HTTP
     */
    public function method(): string
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * URI solicitada
     */
    public function uri(): string
    {
        return parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    }

    /**
     * Verificar si existe un campo
     */
    public function has(string $key): bool
    {
        return isset($_REQUEST[$key]);
    }

    /**
     * Obtener cualquier parámetro (GET o POST)
     */
    public function input(string $key, mixed $default = null): mixed
    {
        return $_REQUEST[$key] ?? $default;
    }
}