<?php

namespace App\Services;

class TangoService
{
    public static function getCatalog(): array
    {
        return [
            'catalogName' => 'GRL-UNLOCK Tango Test Catalog',

            'brands' => [
                [
                    'brand_key' => 'amazon',
                    'brand_name' => 'Amazon',
                    'utid' => 'AMAZON-25-USD',
                    'reward_name' => 'Amazon Gift Card $25',
                    'currency' => 'USD',
                    'face_value' => 25,
                    'fulfillment_type' => 'DIGITAL',
                    'status' => 'active'
                ],

                [
                    'brand_key' => 'xbox',
                    'brand_name' => 'Xbox',
                    'utid' => 'XBOX-50-USD',
                    'reward_name' => 'Xbox Gift Card $50',
                    'currency' => 'USD',
                    'face_value' => 50,
                    'fulfillment_type' => 'DIGITAL',
                    'status' => 'active'
                ]
            ]
        ];
    }
}