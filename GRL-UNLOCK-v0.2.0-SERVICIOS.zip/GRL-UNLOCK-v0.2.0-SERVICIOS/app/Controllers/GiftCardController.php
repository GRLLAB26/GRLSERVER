<?php

namespace App\Controllers;

use App\Models\GiftCard;

class GiftCardController
{
    public function index()
    {
        $gift_cards = GiftCard::all();

        require __DIR__ . '/../../resources/views/gift_cards/index.php';
    }

    public function create()
    {
        require __DIR__ . '/../../resources/views/gift_cards/create.php';
    }

    public function store()
    {
        GiftCard::create($_POST);

        header("Location: /gift-cards");
        exit;
    }
}