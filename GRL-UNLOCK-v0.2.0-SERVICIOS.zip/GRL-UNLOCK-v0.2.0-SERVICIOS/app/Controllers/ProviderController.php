<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Provider;

class ProviderController extends Controller
{
    public function index(): void
    {
        $this->view('providers/index', [
            'title' => 'Providers',
            'providers' => Provider::all()
        ]);
    }

    public function create(): void
    {
        $this->view('providers/create', [
            'title' => 'Nuevo Provider'
        ]);
    }

    public function store(): void
    {
        $request = $this->request();

        Provider::create([
            'name'      => $request->input('name'),
            'website'   => $request->input('website'),
            'api_url'   => $request->input('api_url'),
            'username'  => $request->input('username'),
            'api_key'   => $request->input('api_key'),
            'currency'  => $request->input('currency'),
            'balance'   => $request->input('balance'),
            'status'    => 1
        ]);

        $this->redirect('/providers');
    }


    public function edit(int $id): void
    {
        $this->view('providers/edit', [
            'title' => 'Editar Provider',
            'provider' => Provider::find($id)
        ]);
    }


    public function update(int $id): void
    {
        $request = $this->request();

        Provider::update($id, [
            'name'      => $request->input('name'),
            'website'   => $request->input('website'),
            'api_url'   => $request->input('api_url'),
            'username'  => $request->input('username'),
            'api_key'   => $request->input('api_key'),
            'currency'  => $request->input('currency'),
            'balance'   => $request->input('balance')
        ]);

        $this->redirect('/providers');
    }


    public function delete(int $id): void
    {
        Provider::delete($id);

        $this->redirect('/providers');
    }
}