<?php

namespace App\Controllers;

use App\Models\GiftCardSale;
use App\Models\Client;

class GiftCardSaleController
{
    public function index()
    {
        $sales = GiftCardSale::all();

        require __DIR__ . '/../../resources/views/gift_card_sales/index.php';
    }

    public function create()
    {
        $clients = Client::all();

        require __DIR__ . '/../../resources/views/gift_card_sales/create.php';
    }

    public function store()
    {
        GiftCardSale::create($_POST);

        header("Location: /gift-card-sales");
        exit;
    }
}