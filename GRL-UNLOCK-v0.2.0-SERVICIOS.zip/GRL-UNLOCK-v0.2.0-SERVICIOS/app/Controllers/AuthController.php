<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Services\AuthService;

class AuthController extends Controller
{
    private AuthService $auth;

    public function __construct()
    {
        $this->auth = new AuthService();
    }

    public function index(): void
    {
        $this->view('auth/login', [
            'title' => 'Iniciar sesión'
        ]);
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($this->auth->login($email, $password)) {
            $this->redirect('/dashboard');
        }

        $this->view('auth/login', [
            'title' => 'Iniciar sesión',
            'error' => 'Correo o contraseña incorrectos.'
        ]);
    }

    public function logout(): void
    {
        $this->auth->logout();

        $this->redirect('/login');
    }
}