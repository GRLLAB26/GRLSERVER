<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Service;

class ServiceController extends Controller
{
    /**
     * Mostrar listado de servicios
     */
    public function index(): void
    {
        $services = Service::all();

        $this->view('services/index', [
            'title' => 'Servicios',
            'services' => $services
        ]);
    }

    /**
     * Mostrar formulario para crear servicio
     */
    public function create(): void
    {
        $this->view('services/create', [
            'title' => 'Nuevo Servicio'
        ]);
    }

    /**
     * Guardar servicio
     */
    public function store(): void
    {
        $request = $this->request();

        $ok = Service::create([
            'name' => $request->input('name'),
            'provider' => $request->input('provider'),
            'category' => $request->input('category'),
            'cost' => $request->input('cost'),
            'price' => $request->input('price'),
            'estimated_time' => $request->input('estimated_time'),
            'status' => 1,
        ]);

        if (!$ok) {
            exit('No se pudo guardar el servicio.');
        }

        $this->redirect('/services');
    }

    /**
     * Mostrar formulario para editar un servicio
     */
    public function edit(): void
{
    $id = (int) ($_GET['id'] ?? 0);

    $service = Service::find($id);

        if (!$service) {
            http_response_code(404);
            exit('Servicio no encontrado.');
        }

        $this->view('services/edit', [
            'title' => 'Editar Servicio',
            'service' => $service
        ]);
    }
    public function update(): void
{
    $request = $this->request();

    $id = (int) ($_GET['id'] ?? 0);

    $ok = Service::update($id, [
        'name' => $request->input('name'),
        'provider' => $request->input('provider'),
        'category' => $request->input('category'),
        'cost' => $request->input('cost'),
        'price' => $request->input('price'),
        'estimated_time' => $request->input('estimated_time'),
        'status' => 1,
    ]);

    if (!$ok) {
        exit('No se pudo actualizar el servicio.');
    }

    $this->redirect('/services');
}
/**
 * Desactivar servicio
 */
public function destroy(): void
{
    $id = (int) ($_POST['id'] ?? 0);

    $ok = Service::deactivate($id);

    if (!$ok) {
        exit('No se pudo desactivar el servicio.');
    }

    $this->redirect('/services');
}
}