<?php

namespace App\Controllers;

use App\Services\TangoService;
use App\Models\GiftCard;

class TangoController
{
    public function sync()
    {
        $catalog = TangoService::getCatalog();

        $brands = $catalog['brands'] ?? [];

        $insertados = 0;

        foreach ($brands as $brand) {

            GiftCard::create([
                'provider_id' => 1,
                'brand_key' => $brand['brand_key'],
                'brand_name' => $brand['brand_name'],
                'utid' => $brand['utid'],
                'reward_name' => $brand['reward_name'],
                'currency' => $brand['currency'],
                'face_value' => $brand['face_value'],
                'fulfillment_type' => $brand['fulfillment_type'],
                'status' => $brand['status'],
            ]);

            $insertados++;
        }

        echo "
            Catálogo Tango sincronizado<br>
            Nombre catálogo: {$catalog['catalogName']}<br>
            Marcas importadas: {$insertados}
        ";
    }
}