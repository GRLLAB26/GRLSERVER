<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Service;
use App\Models\Client;
use App\Models\Order;

class DashboardController extends Controller
{
    public function index(): void
    {
        $this->view('dashboard/index', [
            'title'    => 'Dashboard',
            'services' => Service::count(),
            'clients'  => Client::count(),
            'orders'   => Order::count(),
            'balance'  => Service::totalBalance(),
        ]);
    }
}