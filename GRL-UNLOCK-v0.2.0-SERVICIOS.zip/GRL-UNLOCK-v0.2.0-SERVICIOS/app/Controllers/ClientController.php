<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Client;

class ClientController extends Controller
{
    /**
     * Mostrar listado de clientes
     */
    public function index(): void
    {
        $clients = Client::all();

        $this->view('clients/index', [
            'title' => 'Clientes',
            'clients' => $clients
        ]);
    }

    /**
     * Mostrar formulario para crear cliente
     */
    public function create(): void
    {
        $this->view('clients/create', [
            'title' => 'Nuevo Cliente'
        ]);
    }

    /**
     * Guardar cliente
     */
    public function store(): void
    {
        $request = $this->request();

        $ok = Client::create([
            'name'    => $request->input('name'),
            'phone'   => $request->input('phone'),
            'email'   => $request->input('email'),
            'address' => $request->input('address'),
            'notes'   => $request->input('notes'),
            'status'  => 1
        ]);

        if (!$ok) {
            exit('No se pudo guardar el cliente.');
        }

        $this->redirect('/clients');
    }
}