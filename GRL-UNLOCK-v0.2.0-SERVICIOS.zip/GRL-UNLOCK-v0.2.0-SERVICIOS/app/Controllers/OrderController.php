<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Order;
use App\Models\Client;
use App\Models\Service;

class OrderController extends Controller
{

    public function store(): void
    {
        $request = $this->request();

        $service = Service::find(
            $request->input('service_id')
        );

        if (!$service) {
            exit('Servicio no encontrado.');
        }

        $ok = Order::create([

            'client_id'     => $request->input('client_id'),
            'service_id'    => $request->input('service_id'),
            'device'        => $request->input('device'),
            'brand'         => $request->input('brand'),
            'model'         => $request->input('model'),
            'imei'          => $request->input('imei'),
            'serial_number' => $request->input('serial_number'),
            'color'         => $request->input('color'),
            'password'      => $request->input('password'),
            'problem'       => $request->input('problem'),
            'notes'         => $request->input('notes'),
            'status'        => 'Pendiente',
            'price'         => $service['price'],
            'advance'       => $request->input('advance') ?? 0,
            'delivery_date' => $request->input('delivery_date')
        ]);

        if (!$ok) {
            exit('No se pudo guardar la orden.');
        }

        $this->redirect('/orders');
    }


    public function index(): void
    {
        $orders = Order::all();

        $this->view('orders/index', [
            'title' => 'Órdenes',
            'orders' => $orders
        ]);
    }


    public function create(): void
    {
        $this->view('orders/create', [
            'title' => 'Nueva Orden',
            'clients' => Client::all(),
            'services' => Service::all()
        ]);
    }
public function show(int $id): void
{
    $order = Order::find($id);

    if (!$order) {
        exit('Orden no encontrada.');
    }

    $this->view('orders/view', [
        'title' => 'Detalle de Orden',
        'order' => $order
    ]);
}
public function status(int $id): void
{
    $request = $this->request();

    $status = $request->input('status');

    Order::updateStatus($id, $status);

    $this->redirect('/orders/view/'.$id);
}

}