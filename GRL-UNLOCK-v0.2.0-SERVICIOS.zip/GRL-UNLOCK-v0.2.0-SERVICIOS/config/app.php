<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Información de la aplicación
    |--------------------------------------------------------------------------
    */

    'name' => 'GRL-UNLOCK',

    'version' => '0.1.0 Alpha',

    'environment' => getenv('APP_ENV') ?: 'development',

    'debug' => filter_var(getenv('APP_DEBUG') ?: true, FILTER_VALIDATE_BOOLEAN),

    'url' => getenv('APP_URL') ?: 'http://localhost:8000',

    'timezone' => 'America/Mexico_City',

    'locale' => 'es_MX',

    /*
    |--------------------------------------------------------------------------
    | Seguridad
    |--------------------------------------------------------------------------
    */

    'session_name' => 'grl_unlock_session',

    'csrf_token_name' => '_token',

];