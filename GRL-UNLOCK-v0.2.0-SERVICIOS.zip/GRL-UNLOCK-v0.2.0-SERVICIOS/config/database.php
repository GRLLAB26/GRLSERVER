<?php

return [
    'driver'   => 'mysql',
    'host'     => '127.0.0.1',
    'port'     => 3306,
    'database' => 'grl_unlock',
    'username' => 'root',
    'password' => 'R5joRgito1987',
    'charset'  => 'utf8mb4',
];