<?php

use App\Core\Router;
use App\Controllers\AuthController;
use App\Controllers\DashboardController;
use App\Controllers\ServiceController;
use App\Controllers\ClientController;
use App\Controllers\OrderController;
use App\Controllers\ProviderController;
use App\Controllers\TangoController;
use App\Controllers\GiftCardController;
use App\Controllers\GiftCardSaleController;
$router = new Router();

$router->get('/gift-cards', [
    GiftCardController::class,
    'index'
]);

$router->get('/gift-cards/create', [
    GiftCardController::class,
    'create'
]);

$router->post('/gift-cards', [
    GiftCardController::class,
    'store'
]);
$router->get('/gift-card-sales', [
    GiftCardSaleController::class,
    'index'
]);

$router->get('/gift-card-sales/create', [
    GiftCardSaleController::class,
    'create'
]);

$router->post('/gift-card-sales', [
    GiftCardSaleController::class,
    'store'
]);
/*
|--------------------------------------------------------------------------
| Inicio
|--------------------------------------------------------------------------
*/
/*
|--------------------------------------------------------------------------
| Autenticación
|--------------------------------------------------------------------------
*/

$router->get('/login', [
    AuthController::class,
    'index'
]);

$router->post('/login', [
    AuthController::class,
    'login'
]);

$router->get('/logout', [
    AuthController::class,
    'logout'
]);

/*
|--------------------------------------------------------------------------
| Dashboard
|--------------------------------------------------------------------------
*/

$router->get('/dashboard', [
    DashboardController::class,
    'index'
]);

/*
|--------------------------------------------------------------------------
| Servicios
|--------------------------------------------------------------------------
*/

$router->get('/services', [
    ServiceController::class,
    'index'
]);

$router->get('/services/create', [
    ServiceController::class,
    'create'
]);

$router->post('/services', [
    ServiceController::class,
    'store'
]);
/*
|--------------------------------------------------------------------------
| Editar Servicio
|--------------------------------------------------------------------------
*/

$router->get('/services/edit', [
    ServiceController::class,
    'edit'
]);

$router->post('/services/update', [
    ServiceController::class,
    'update'
]);

$router->post('/services/delete', [
    ServiceController::class,
    'destroy'
]);
/*
|--------------------------------------------------------------------------
| Clientes
|--------------------------------------------------------------------------
*/

$router->get('/clients', [
    ClientController::class,
    'index'
]);

$router->get('/clients/create', [
    ClientController::class,
    'create'
]);

/*
|--------------------------------------------------------------------------
| Órdenes
|--------------------------------------------------------------------------
*/

$router->get('/orders', [
    OrderController::class,
    'index'
]);

$router->get('/orders/create', [
    OrderController::class,
    'create'
]);

$router->get('/orders/view/{id}', [
    OrderController::class,
    'show'
]);

$router->post('/orders', [
    OrderController::class,
    'store'
]);
$router->post('/orders/status/{id}', [
    OrderController::class,
    'status'
]);
/*
|--------------------------------------------------------------------------
| IMEI Services
|--------------------------------------------------------------------------
*/

$router->get('/orders/imei', [
    OrderController::class,
    'imei'
]);

/*
|--------------------------------------------------------------------------
| Server Services
|--------------------------------------------------------------------------
*/

$router->get('/orders/server', [
    OrderController::class,
    'server'
]);

/*
|--------------------------------------------------------------------------
| Remote Services
|--------------------------------------------------------------------------
*/

$router->get('/orders/remote', [
    OrderController::class,
    'remote'
]);
/*
|--------------------------------------------------------------------------
| Providers
|--------------------------------------------------------------------------
*/

$router->get('/providers', [
    ProviderController::class,
    'index'
]);

$router->get('/providers/create', [
    ProviderController::class,
    'create'
]);

$router->post('/providers', [
    ProviderController::class,
    'store'
]);
/*
|--------------------------------------------------------------------------
| Editar Providers
|--------------------------------------------------------------------------
*/

$router->get('/providers/edit/{id}', [
    ProviderController::class,
    'edit'
]);

$router->post('/providers/update/{id}', [
    ProviderController::class,
    'update'
]);

$router->get('/providers/delete/{id}', [
    ProviderController::class,
    'delete'
]);
/*
|--------------------------------------------------------------------------
| Tango API Test
|--------------------------------------------------------------------------
*/

$router->get('/tango/test', [
    TangoController::class,
    'test'
]);

/*
|--------------------------------------------------------------------------
| Tango Sync Catalog
|--------------------------------------------------------------------------
*/

$router->get('/tango/sync', [
    TangoController::class,
    'sync'
]);

return $router;